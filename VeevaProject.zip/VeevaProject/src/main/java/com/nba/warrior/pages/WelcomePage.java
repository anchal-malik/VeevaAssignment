package com.nba.warrior.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class WelcomePage  extends BasePage{

	 
	 private String PageUrl = "https://www.nba.com/warriors";
	 private By xclickLocator = By.xpath("/html/body/div[4]/div[1]/div");
	private By iAcceptLocator = By.id("onetrust-accept-btn-handler");
	 
	public WelcomePage(WebDriver driver) {
		super(driver);
	}
	
	public void OpenPage() {
		System.out.println("Opening Page: " + PageUrl);
		openUrl(PageUrl);
	}
	
	public void clickX () {
		click(xclickLocator);
	}
	
	public void iAccept() {
		System.out.println("Clicking on Accept Cookies");
		click(iAcceptLocator);
	}


}
