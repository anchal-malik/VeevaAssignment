package com.nba.warrior.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoadMorePage extends BasePage {

	private By LoadMoreLocator = By.xpath("//span[text()='Load more']");
	public LoadMorePage(WebDriver driver) {
       super(driver);
	}
	
	public void LoadMoreClick() {
		System.out.println("Clicking on Load More Button");
		//WebElement initialXpath = find(LoadMoreLocator);
		while(LoadMoreLocator != null) {
	WebElement loadMoreClick = find(LoadMoreLocator);
	ClickAndHold(loadMoreClick);
	System.out.println("Clicked on Load More Button");
		}
	}

}
