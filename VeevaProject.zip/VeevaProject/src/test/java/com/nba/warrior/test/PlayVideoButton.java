package com.nba.warrior.test;

import org.testng.annotations.Test;

import com.nba.warrior.base.TestUtilities;
import com.nba.warrior.pages.VideoPlayPage;
import com.nba.warrior.pages.WelcomePage;

public class PlayVideoButton extends TestUtilities {
	
	@Test
	public void PlayButton()
	{
 System.out.println("Opening the main page");
		 
		 //open main page
		 WelcomePage welcomePage = new WelcomePage(driver);
		 welcomePage.OpenPage();
		 
		 //click on X of pop up
		 welcomePage.clickX();
		 
		 //click on IAccept
		 welcomePage.iAccept();
		 
		 VideoPlayPage vp = new VideoPlayPage(driver);
		 vp.PlayVideo();
	}
}
