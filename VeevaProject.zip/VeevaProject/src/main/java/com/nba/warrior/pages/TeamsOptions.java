package com.nba.warrior.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TeamsOptions  extends BasePage{

	 private By TeamsLinkLocator = By.xpath("//*[@id='nba-nav']/nav/div/ul/li[1]/button/");

	//private By atlanticsTeamLocator = By.xpath("//span[text() ='Atlantic']//following-sibling::ul/li");
	private By atlanticsTeamLocator = By.xpath("//span[@class='dark-primary-color font-bold mb-2 uppercase']//following-sibling::ul/li");
	//private By atlanticsTeamLocator = By.xpath("//*[@id='teams']/div[1]/ul/li");
	
private By centralTeamLocator = By.xpath("//*[@id='teams']/div[2]/ul/li");
 private By sothEastTeamLocator =  By.xpath("//*[@id='teams']/div[3]/ul/li");
 private By northWestTeamLocator = By.xpath("//*[@id=\"teams\"]/div[4]/ul/li");
 private By pacificTeamLocator = By.xpath("//*[@id=\"teams\"]/div[5]/ul/li");
 private By southWestTeamLocator = By.xpath("//*[@id=\"teams\"]/div[6]/ul/li");
 
 
	public TeamsOptions(WebDriver driver) {
		super(driver);
	}
	
	public void clickTeamsLinkLocator() {
		System.out.println("Clicking on Teams Option");
		WebElement teamsElement = find(TeamsLinkLocator);
	ClickAndHold(teamsElement);
	System.out.println("Clicking on Teams Option completed");
	}
	
	// Atlantics Team
	public void AtlanticTeam() {
		System.out.println("Navigating to Atlantics Team");
		
		// getting names of Atlantics Teams

		List<WebElement> atlanticTeam = findAll(atlanticsTeamLocator);
		System.out.println("Number of Atlantics Teams: " + atlanticTeam.size());
		
		for (WebElement atlantic : atlanticTeam) {
			System.out.println("anchor - " + atlantic.getText());
		}
	} 
	
	// Central Team
		public void CentralTeam() {
			System.out.println("Navigating to CentralTeam");
			
			// getting names of CentralTeams

			List<WebElement> centralTeam = findAll(centralTeamLocator);
			System.out.println("Number of Central Teams: " + centralTeam.size());
			
			for (WebElement central : centralTeam) {
				System.out.println("anchor - " + central.getText());
			}
			
		}  
		
		//southeast team
				public void SouthEastTeam() {
					System.out.println("Navigating to SouthEastTeam");
					
					// getting names of SouthEastTeams

					List<WebElement> southEastTeam = findAll(sothEastTeamLocator);
					System.out.println("Number of SouthEast Teams: " + southEastTeam.size());
					
					for (WebElement southEast : southEastTeam) {
						System.out.println("anchor - " + southEast.findElement(By.tagName("a")).getText());
					}
					
				}
				
				//northWest team
				public void NorthWestTeam() {
					System.out.println("Navigating to NorthWestTeam");
					
					// getting names of NorthWestTeam

					List<WebElement> northWestTeam = findAll(northWestTeamLocator);
					System.out.println("Number of northWest Teams: " + northWestTeam.size());
					
					for (WebElement northWest : northWestTeam) {
						System.out.println("anchor - " + northWest.findElement(By.tagName("a")).getText());
					}
					
				}
				
				//Pacific team
				public void PacificTeam() {
					System.out.println("Navigating to PacificTeam");
					
					// getting names of pacificTeam

					List<WebElement> pacificTeam = findAll(pacificTeamLocator);
					System.out.println("Number of pacificTeam Teams: " + pacificTeam.size());
					
					for (WebElement pacific : pacificTeam) {
						System.out.println("anchor - " + pacific.findElement(By.tagName("a")).getText());
					}
					
				}
				
				//SouthWest team
				public void SouthWestTeam() {
					System.out.println("Navigating to SouthWestTeam");
					
					// getting names of SouthWestTeam

					List<WebElement> southWestTeam = findAll(southWestTeamLocator);
					System.out.println("Number of southWest Teams: " + southWestTeam.size());
					
					for (WebElement southWest : southWestTeam) {
						System.out.println("anchor - " + southWest.findElement(By.tagName("a")).getText());
					}
					
				}
				
}
