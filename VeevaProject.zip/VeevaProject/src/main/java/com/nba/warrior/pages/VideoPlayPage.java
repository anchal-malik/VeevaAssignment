package com.nba.warrior.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class VideoPlayPage  extends BasePage{
	
	private By videoPlayLocator = By.xpath("//*[@id='__next']/div[2]/main/div[3]/div[3]/div/div/div[2]/div/div[2]/div[2]/a/div");

	public VideoPlayPage(WebDriver driver) {
		super(driver);
	}
	
	public void PlayVideo() {
		click(videoPlayLocator);
		
		System.out.println("Video will be played");
		
	}

}
