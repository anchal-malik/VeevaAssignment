package com.nba.warrior.pages;

import org.openqa.selenium.WebDriver;

public class SlideViewPage extends BasePage {
	
	//private By arrowButtonLocator = By.

	public SlideViewPage(WebDriver driver) {
		
		super(driver);
	}

}
