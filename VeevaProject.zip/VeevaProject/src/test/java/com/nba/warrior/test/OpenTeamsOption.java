package com.nba.warrior.test;

import org.testng.annotations.Test;

import com.nba.warrior.base.TestUtilities;
import com.nba.warrior.pages.LoadMorePage;
import com.nba.warrior.pages.TeamsOptions;
import com.nba.warrior.pages.WelcomePage;

public class OpenTeamsOption extends TestUtilities {

	@Test
	public void selectTeam() {
		
		 System.out.println("Opening the main page");
		 
		 //open main page
		 WelcomePage welcomePage = new WelcomePage(driver);
		 welcomePage.OpenPage();
		 
		 //click on X of pop up
		 welcomePage.clickX();
		 
		 //click on IAccept
		 welcomePage.iAccept();
		 
		 //click on Teams
		 TeamsOptions toption = new TeamsOptions(driver);
		 toption.clickTeamsLinkLocator();
		 
		 //get Atlantics Team size
		 
		 toption.AtlanticTeam();
		 
		// toption.CentralTeam();
		 
		 //click on LoadMore option
		 LoadMorePage lm = new LoadMorePage(driver);
		 lm.LoadMoreClick();
	}

}
