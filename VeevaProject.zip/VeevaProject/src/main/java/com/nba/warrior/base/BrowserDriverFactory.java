package com.nba.warrior.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserDriverFactory {

	private ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	private String browser;
	
	public BrowserDriverFactory(String browser) {
		this.browser = browser.toLowerCase();
			}
	public WebDriver createDriver() {
		// Create driver
		System.out.println("Create driver: " + browser);
		
		System.setProperty("webdriver.chrome.driver", "/Users/aanchalmalik/Documents/SeleniumDrivers/chromedriver");
		driver.set(new ChromeDriver());
		
		return driver.get();
	}
}
